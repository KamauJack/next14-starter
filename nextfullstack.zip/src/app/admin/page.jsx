const RegisterPage = () => {
  return <div>RegisterPage</div>;
};

export default RegisterPage;
