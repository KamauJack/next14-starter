const SinglePostPage = () => {
  return <div>SinglePostPage</div>;
};

export default SinglePostPage;
